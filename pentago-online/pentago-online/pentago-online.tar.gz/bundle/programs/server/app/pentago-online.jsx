(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// pentago-online.jsx                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Define a collection to hold our tasks                               //
Games = new Mongo.Collection("games");                                 // 2
                                                                       //
if (Meteor.isClient) {                                                 // 4
  Accounts.ui.config({                                                 // 5
    passwordSignupFields: "USERNAME_ONLY"                              // 6
  });                                                                  //
                                                                       //
  Meteor.startup(function () {                                         // 9
    ReactDOM.render(React.createElement(App, null), document.getElementById("render-target"));
  });                                                                  //
                                                                       //
  Meteor.subscribe("games");                                           // 16
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 19
  Meteor.startup(function () {});                                      // 20
                                                                       //
  // Meteor.publish("new-games", function () {                         //
  //   return Games.find({state: "getting-players"});                  //
  // });                                                               //
                                                                       //
  // Meteor.publish("playing-games", function () {                     //
  //   return Games.find({state: "playing"});                          //
  // });                                                               //
                                                                       //
  // Meteor.publish("finished-games", function () {                    //
  //   return Games.find({state: "finished"});                         //
  // });                                                               //
                                                                       //
  Meteor.publish("games", function () {                                // 36
    return Games.find({});                                             // 37
  });                                                                  //
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 41
  createGame: function (name, numberOfPlayers) {                       // 42
    // Make sure the user is logged in before inserting a task         //
    if (!Meteor.userId()) {                                            // 44
      throw new Meteor.Error("not-authorized");                        // 45
    }                                                                  //
                                                                       //
    var gameId = Games.insert({                                        // 48
      name: name,                                                      // 49
      numberOfPlayers: numberOfPlayers,                                // 50
      state: "getting-players",                                        // 51
      players: [Meteor.user()],                                        // 52
      createdAt: new Date(),                                           // 53
      stateHistory: [],                                                // 54
      moveHistory: [],                                                 // 55
      creator: Meteor.user()                                           // 56
    });                                                                //
                                                                       //
    return gameId;                                                     // 59
  },                                                                   //
                                                                       //
  joinGame: function (gameId) {                                        // 62
    var game = Games.findOne({ _id: gameId });                         // 63
                                                                       //
    if (game.players.length == game.numberOfPlayers - 1) {             // 65
      var shuffledPlayers = shuffle(game.players.concat([Meteor.user()]));
                                                                       //
      var board = [];                                                  // 68
                                                                       //
      for (var y = 0; y < 9; y++) {                                    // 70
        var row = [];                                                  // 71
        for (var x = 0; x < 9; x++) {                                  // 72
          row.push(0);                                                 // 73
        };                                                             //
        board.push(row);                                               // 75
      };                                                               //
                                                                       //
      Games.update(game._id, {                                         // 78
        $set: { state: "playing", players: shuffledPlayers, board: board, currentTurn: 0, placingPiece: true }
      });                                                              //
    } else {                                                           //
      Games.update(gameId, {                                           // 82
        $set: { players: game.players.concat([Meteor.user()]) }        // 83
      });                                                              //
    }                                                                  //
  },                                                                   //
                                                                       //
  playPiece: function (gameId, x, y) {                                 // 88
    var game = Games.findOne({ _id: gameId });                         // 89
    var board = game.board;                                            // 90
    var playerNumber = game.players.map(function (x) {                 // 91
      return x._id;                                                    //
    }).indexOf(Meteor.userId());                                       //
                                                                       //
    if (!game.placingPiece || playerNumber == -1 || playerNumber != game.currentTurn) {
      throw new Meteor.Error("not-authorized");                        // 94
    }                                                                  //
                                                                       //
    board[y][x] = playerNumber + 1;                                    // 97
                                                                       //
    Games.update(game._id, {                                           // 99
      $set: {                                                          // 100
        board: board,                                                  // 101
        placingPiece: false                                            // 102
      }                                                                //
    });                                                                //
  },                                                                   //
                                                                       //
  playPiece: function (gameId, x, y) {                                 // 107
    var game = Games.findOne({ _id: gameId });                         // 108
    var board = game.board;                                            // 109
    var playerNumber = game.players.map(function (x) {                 // 110
      return x._id;                                                    //
    }).indexOf(Meteor.userId());                                       //
                                                                       //
    if (!game.placingPiece || playerNumber == -1 || playerNumber != game.currentTurn) {
      throw new Meteor.Error("not-authorized");                        // 113
    }                                                                  //
                                                                       //
    if (board[y][x] != 0) {                                            // 116
      throw new Meteor.Error("bad-request");                           // 117
    }                                                                  //
                                                                       //
    board[y][x] = playerNumber + 1;                                    // 120
                                                                       //
    if (playerHasWon(board)) {                                         // 122
      winGame(game, board);                                            // 123
    } else {                                                           //
      Games.update(game._id, {                                         // 125
        $set: {                                                        // 126
          board: board,                                                // 127
          placingPiece: false                                          // 128
        }                                                              //
      });                                                              //
    }                                                                  //
  },                                                                   //
                                                                       //
  playRotation: function (gameId, rotateX, rotateY, clockwise) {       // 134
    var game = Games.findOne({ _id: gameId });                         // 135
    var board = game.board;                                            // 136
    var playerNumber = game.players.map(function (x) {                 // 137
      return x._id;                                                    //
    }).indexOf(Meteor.userId());                                       //
                                                                       //
    // if (game.placingPiece || playerNumber == -1 || playerNumber != game.currentTurn) {
    //   throw new Meteor.Error("not-authorized");                     //
    // }                                                               //
                                                                       //
    // shitty deep copy                                                //
    var newBoard = JSON.parse(JSON.stringify(game.board));             // 144
                                                                       //
    var startX = rotateX * 3;                                          // 146
    var startY = rotateY * 3;                                          // 147
                                                                       //
    for (var x = 0; x < 3; x++) {                                      // 149
      for (var y = 0; y < 3; y++) {                                    // 150
        if (clockwise) {                                               // 151
          newBoard[x + startY][3 - y - 1 + startX] = board[startY + y][startX + x];
        } else {                                                       //
          newBoard[3 - x - 1 + startY][y + startX] = board[startY + y][startX + x];
        }                                                              //
      }                                                                //
    }                                                                  //
                                                                       //
    if (playerHasWon(newBoard)) {                                      // 159
      winGame(game, newBoard);                                         // 160
    } else {                                                           //
      Games.update(game._id, {                                         // 162
        $set: {                                                        // 163
          board: newBoard,                                             // 164
          placingPiece: true,                                          // 165
          currentTurn: (game.currentTurn + 1) % game.numberOfPlayers   // 166
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
function winGame(game, board) {                                        // 173
  Games.update(game._id, {                                             // 174
    $set: {                                                            // 175
      board: board,                                                    // 176
      state: "finished",                                               // 177
      winner: Meteor.user(),                                           // 178
      currentTurn: -1                                                  // 179
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
function playerHasWon(board) {                                         // 184
  var directions = [[0, 1], [1, 0], [1, -1], [1, 1]];                  // 185
  for (var x = 0; x < 9; x++) {                                        // 186
    for (var y = 0; y < 9; y++) {                                      // 187
      for (var i = 0; i < directions.length; i++) {                    // 188
        var direction = directions[i];                                 // 189
                                                                       //
        var length = 0;                                                // 191
        var player = board[y][x];                                      // 192
                                                                       //
        if (player != 0) {                                             // 194
          var currX = x;                                               // 195
          var currY = y;                                               // 196
                                                                       //
          while (currX < 9 && currX >= 0 && currY < 9 && currY >= 0 && board[currY][currX] == player) {
            length += 1;                                               // 199
            currX += direction[0];                                     // 200
            currY += direction[1];                                     // 201
            if (length == 5) {                                         // 202
              return true;                                             // 203
            }                                                          //
          }                                                            //
        }                                                              //
      };                                                               //
    }                                                                  //
  };                                                                   //
                                                                       //
  return false;                                                        // 211
}                                                                      //
                                                                       //
function shuffle(array) {                                              // 214
  var currentIndex = array.length,                                     // 215
      temporaryValue,                                                  //
      randomIndex;                                                     //
                                                                       //
  // While there remain elements to shuffle...                         //
  while (0 !== currentIndex) {                                         // 218
                                                                       //
    // Pick a remaining element...                                     //
    randomIndex = Math.floor(Math.random() * currentIndex);            // 221
    currentIndex -= 1;                                                 // 222
                                                                       //
    // And swap it with the current element.                           //
    temporaryValue = array[currentIndex];                              // 225
    array[currentIndex] = array[randomIndex];                          // 226
    array[randomIndex] = temporaryValue;                               // 227
  }                                                                    //
                                                                       //
  return array;                                                        // 230
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=pentago-online.jsx.map
