(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// components/App.jsx                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
App = React.createClass({                                              // 1
  displayName: "App",                                                  //
                                                                       //
  mixins: [ReactMeteorData],                                           // 2
                                                                       //
  getInitialState: function () {                                       // 4
    return {                                                           // 5
      state: "list"                                                    // 6
    };                                                                 //
  },                                                                   //
                                                                       //
  getMeteorData: function () {                                         // 10
    return {                                                           // 11
      games: Games.find({}).fetch(),                                   // 12
      gamesGettingPlayers: Games.find({ state: "getting-players" }).fetch(),
      gamesPlaying: Games.find({ state: "playing" }).fetch(),          // 14
      gamesFinished: Games.find({ state: "finished" }).fetch(),        // 15
      user: Meteor.user(),                                             // 16
      userId: Meteor.userId()                                          // 17
    };                                                                 //
  },                                                                   //
                                                                       //
  handleGameSelect: function (_id) {                                   // 21
    this.setState({ state: "view-game", currentGameId: _id });         // 22
  },                                                                   //
                                                                       //
  goToMainMenu: function () {                                          // 25
    this.setState({ state: "list" });                                  // 26
  },                                                                   //
                                                                       //
  handleCreateGame: function (event) {                                 // 29
    event.preventDefault();                                            // 30
                                                                       //
    // Find the text field via the React ref                           //
    var name = ReactDOM.findDOMNode(this.refs.nameInput).value.trim();
    var numberOfPlayers = parseInt(document.querySelector('input[name="playerNumber"]:checked').value);
    var that = this;                                                   // 35
                                                                       //
    Meteor.call("createGame", name, numberOfPlayers, function (err, gameId) {
      that.setState({ state: "view-game", currentGameId: gameId });    // 38
    });                                                                //
  },                                                                   //
                                                                       //
  render: function () {                                                // 42
    var _this = this;                                                  //
                                                                       //
    // Get tasks from this.data.tasks                                  //
                                                                       //
    var inner = React.createElement("p", null);                        // 45
                                                                       //
    if (this.state.state == "list") {                                  // 47
      inner = React.createElement(                                     // 48
        "div",                                                         //
        null,                                                          //
        React.createElement(                                           //
          "div",                                                       //
          { className: "panel panel-default" },                        //
          React.createElement(                                         //
            "div",                                                     //
            { className: "panel-body" },                               //
            React.createElement(                                       //
              "h3",                                                    //
              null,                                                    //
              "Join a game!"                                           //
            ),                                                         //
            this.data.games.length ? React.createElement(              //
              "ul",                                                    //
              null,                                                    //
              this.data.gamesGettingPlayers.map(function (game) {      //
                return React.createElement(GameListItem, { handleGameSelect: _this.handleGameSelect, key: game._id, game: game });
              })                                                       //
            ) : React.createElement(                                   //
              "p",                                                     //
              null,                                                    //
              "No games currently exist, create one?"                  //
            )                                                          //
          )                                                            //
        ),                                                             //
        React.createElement(                                           //
          "div",                                                       //
          { className: "panel panel-default" },                        //
          React.createElement(                                         //
            "div",                                                     //
            { className: "panel-body" },                               //
            React.createElement(                                       //
              "h3",                                                    //
              null,                                                    //
              "Currently live matches"                                 //
            ),                                                         //
            this.data.games.length ? React.createElement(              //
              "ul",                                                    //
              null,                                                    //
              this.data.gamesPlaying.map(function (game) {             //
                return React.createElement(GameListItem, { handleGameSelect: _this.handleGameSelect, key: game._id, game: game });
              })                                                       //
            ) : React.createElement(                                   //
              "p",                                                     //
              null,                                                    //
              "No-one is playing right now :("                         //
            )                                                          //
          )                                                            //
        ),                                                             //
        this.data.user && React.createElement(                         //
          "div",                                                       //
          { className: "panel panel-default" },                        //
          React.createElement(                                         //
            "div",                                                     //
            { className: "panel-body" },                               //
            React.createElement(                                       //
              "h3",                                                    //
              null,                                                    //
              "Make new game!"                                         //
            ),                                                         //
            React.createElement(                                       //
              "form",                                                  //
              { onSubmit: this.handleCreateGame },                     //
              React.createElement("input", {                           //
                className: "form-control",                             // 84
                type: "text",                                          // 85
                ref: "nameInput",                                      // 86
                placeholder: "Name of game",                           // 87
                defaultValue: this.data.user.username + "'s cool game" }),
              React.createElement(                                     //
                "div",                                                 //
                { className: "radio" },                                //
                [2, 3, 4].map(function (n) {                           //
                  return React.createElement(                          // 91
                    "label",                                           //
                    { key: n, className: "radio-inline" },             //
                    React.createElement("input", { type: "radio", name: "playerNumber", value: n, defaultChecked: 2 == n }),
                    " ",                                               //
                    n,                                                 //
                    " players"                                         //
                  );                                                   //
                })                                                     //
              ),                                                       //
              React.createElement(                                     //
                "button",                                              //
                { className: "btn btn-primary", type: "submit" },      //
                "Create game"                                          //
              )                                                        //
            )                                                          //
          )                                                            //
        ),                                                             //
        React.createElement(                                           //
          "div",                                                       //
          { className: "panel panel-default" },                        //
          React.createElement(                                         //
            "div",                                                     //
            { className: "panel-body" },                               //
            React.createElement(                                       //
              "h3",                                                    //
              null,                                                    //
              "Old matches"                                            //
            ),                                                         //
            this.data.games.length ? React.createElement(              //
              "ul",                                                    //
              null,                                                    //
              this.data.gamesFinished.map(function (game) {            //
                return React.createElement(GameListItem, { handleGameSelect: _this.handleGameSelect, key: game._id, game: game });
              })                                                       //
            ) : React.createElement(                                   //
              "p",                                                     //
              null,                                                    //
              "No-one has played yet :("                               //
            )                                                          //
          )                                                            //
        )                                                              //
      );                                                               //
    } else if (this.state.state == "view-game") {                      //
      inner = React.createElement(ShowGame, { userId: this.data.userId, game: Games.findOne({ _id: this.state.currentGameId }) });
    }                                                                  //
                                                                       //
    return React.createElement(                                        // 124
      "div",                                                           //
      null,                                                            //
      React.createElement(                                             //
        "div",                                                         //
        { className: "pull-right" },                                   //
        React.createElement(AccountsUIWrapper, null)                   //
      ),                                                               //
      React.createElement(                                             //
        "h1",                                                          //
        { onClick: this.goToMainMenu },                                //
        React.createElement(                                           //
          "a",                                                         //
          null,                                                        //
          "pentago online"                                             //
        )                                                              //
      ),                                                               //
      !this.data.userId && React.createElement(                        //
        "div",                                                         //
        { className: "alert alert-info" },                             //
        "Sign up to play games!"                                       //
      ),                                                               //
      inner                                                            //
    );                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
GameListItem = React.createClass({                                     // 136
  displayName: "GameListItem",                                         //
                                                                       //
  handleClick: function () {                                           // 137
    this.props.handleGameSelect(this.props.game._id);                  // 138
  },                                                                   //
  render: function () {                                                // 140
    var game = this.props.game;                                        // 141
                                                                       //
    var inner;                                                         // 143
                                                                       //
    if (this.props.game.state == "getting-players") {                  // 145
      inner = React.createElement(                                     // 146
        "span",                                                        //
        null,                                                          //
        game.players.length ? React.createElement(                     //
          "span",                                                      //
          null,                                                        //
          "Players: ",                                                 //
          game.players.map(function (x) {                              //
            return x.username;                                         //
          }).join(","),                                                //
          "."                                                          //
        ) : React.createElement(                                       //
          "span",                                                      //
          null,                                                        //
          game.numberOfPlayers,                                        //
          " player game. "                                             //
        ),                                                             //
        " Needs ",                                                     //
        game.numberOfPlayers - game.players.length,                    //
        " more players."                                               //
      );                                                               //
    } else if (game.state == "playing") {                              //
      inner = React.createElement(                                     // 155
        "span",                                                        //
        null,                                                          //
        "Players: ",                                                   //
        game.players.map(function (x) {                                //
          return x.username;                                           //
        }).join(","),                                                  //
        ". Current turn: ",                                            //
        game.players[game.currentTurn].username,                       //
        "."                                                            //
      );                                                               //
    } else if (game.state == "finished") {                             //
      inner = React.createElement(                                     // 160
        "span",                                                        //
        null,                                                          //
        game.winner.username,                                          //
        " won!"                                                        //
      );                                                               //
    }                                                                  //
                                                                       //
    return React.createElement(                                        // 163
      "li",                                                            //
      null,                                                            //
      React.createElement(                                             //
        "a",                                                           //
        { onClick: this.handleClick },                                 //
        game.name                                                      //
      ),                                                               //
      " ",                                                             //
      inner                                                            //
    );                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
ShowGame = React.createClass({                                         // 169
  displayName: "ShowGame",                                             //
                                                                       //
  handleJoin: function () {                                            // 170
    Meteor.call("joinGame", this.props.game._id);                      // 171
  },                                                                   //
  render: function () {                                                // 173
    var game = this.props.game;                                        // 174
                                                                       //
    var inner = React.createElement("p", null);                        // 176
    var that = this;                                                   // 177
                                                                       //
    if (game.state == "getting-players") {                             // 179
      inner = React.createElement(                                     // 180
        "div",                                                         //
        null,                                                          //
        React.createElement(                                           //
          "p",                                                         //
          null,                                                        //
          "Currently waiting on more players! ",                       //
          game.numberOfPlayers - game.players.length,                  //
          " needed."                                                   //
        ),                                                             //
        game.players.length ? React.createElement(                     //
          "div",                                                       //
          null,                                                        //
          React.createElement(                                         //
            "p",                                                       //
            null,                                                      //
            "Players:"                                                 //
          ),                                                           //
          React.createElement(                                         //
            "ul",                                                      //
            null,                                                      //
            game.players.map(function (x) {                            //
              return React.createElement(                              // 187
                "li",                                                  //
                { key: x._id },                                        //
                x.username                                             //
              );                                                       //
            })                                                         //
          )                                                            //
        ) : null,                                                      //
        game.players.map(function (x) {                                //
          return x._id;                                                //
        }).indexOf(that.props.userId) == -1 ? React.createElement(     //
          "button",                                                    //
          { className: "btn btn-primary", onClick: this.handleJoin },  //
          "Join game!"                                                 //
        ) : null                                                       //
      );                                                               //
    } else if (game.state == "playing") {                              //
      inner = React.createElement(                                     // 198
        "div",                                                         //
        null,                                                          //
        React.createElement(Pentago, { size: 9, miniSquareSize: 3, game: game })
      );                                                               //
    } else if (game.state == "finished") {                             //
      inner = React.createElement(                                     // 202
        "div",                                                         //
        null,                                                          //
        React.createElement(Pentago, { size: 9, miniSquareSize: 3, game: game })
      );                                                               //
    }                                                                  //
                                                                       //
    return React.createElement(                                        // 207
      "div",                                                           //
      null,                                                            //
      React.createElement(                                             //
        "h3",                                                          //
        null,                                                          //
        this.props.game.name                                           //
      ),                                                               //
      inner                                                            //
    );                                                                 //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=App.jsx.map
