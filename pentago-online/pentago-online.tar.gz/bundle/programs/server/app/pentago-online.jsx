(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// pentago-online.jsx                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Define a collection to hold our tasks                               //
Games = new Mongo.Collection("games");                                 // 2
                                                                       //
if (Meteor.isClient) {                                                 // 4
  Accounts.ui.config({                                                 // 5
    passwordSignupFields: "USERNAME_ONLY"                              // 6
  });                                                                  //
                                                                       //
  Meteor.startup(function () {                                         // 9
    ReactDOM.render(React.createElement(App, null), document.getElementById("render-target"));
  });                                                                  //
                                                                       //
  Meteor.subscribe("games");                                           // 16
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 19
  Meteor.startup(function () {});                                      // 20
                                                                       //
  // Meteor.publish("new-games", function () {                         //
  //   return Games.find({state: "getting-players"});                  //
  // });                                                               //
                                                                       //
  // Meteor.publish("playing-games", function () {                     //
  //   return Games.find({state: "playing"});                          //
  // });                                                               //
                                                                       //
  // Meteor.publish("finished-games", function () {                    //
  //   return Games.find({state: "finished"});                         //
  // });                                                               //
                                                                       //
  Meteor.publish("games", function () {                                // 36
    return Games.find({});                                             // 37
  });                                                                  //
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 41
  createGame: function (name, numberOfPlayers) {                       // 42
    // Make sure the user is logged in before inserting a task         //
    if (!Meteor.userId()) {                                            // 44
      throw new Meteor.Error("not-authorized");                        // 45
    }                                                                  //
                                                                       //
    var gameId = Games.insert({                                        // 48
      name: name,                                                      // 49
      numberOfPlayers: numberOfPlayers,                                // 50
      state: "getting-players",                                        // 51
      players: [],                                                     // 52
      createdAt: new Date(),                                           // 53
      stateHistory: [],                                                // 54
      moveHistory: []                                                  // 55
    });                                                                //
                                                                       //
    return gameId;                                                     // 58
  },                                                                   //
                                                                       //
  joinGame: function (gameId) {                                        // 61
    var game = Games.findOne({ _id: gameId });                         // 62
                                                                       //
    if (game.players.length == game.numberOfPlayers - 1) {             // 64
      var shuffledPlayers = shuffle(game.players.concat([Meteor.user()]));
                                                                       //
      var board = [];                                                  // 67
                                                                       //
      for (var y = 0; y < 9; y++) {                                    // 69
        var row = [];                                                  // 70
        for (var x = 0; x < 9; x++) {                                  // 71
          row.push(0);                                                 // 72
        };                                                             //
        board.push(row);                                               // 74
      };                                                               //
                                                                       //
      Games.update(game._id, {                                         // 77
        $set: { state: "playing", players: shuffledPlayers, board: board, currentTurn: 0, placingPiece: true }
      });                                                              //
    } else {                                                           //
      Games.update(gameId, {                                           // 81
        $set: { players: game.players.concat([Meteor.user()]) }        // 82
      });                                                              //
    }                                                                  //
  },                                                                   //
                                                                       //
  playPiece: function (gameId, x, y) {                                 // 87
    var game = Games.findOne({ _id: gameId });                         // 88
    var board = game.board;                                            // 89
    var playerNumber = game.players.map(function (x) {                 // 90
      return x._id;                                                    //
    }).indexOf(Meteor.userId());                                       //
                                                                       //
    if (!game.placingPiece || playerNumber == -1 || playerNumber != game.currentTurn) {
      throw new Meteor.Error("not-authorized");                        // 93
    }                                                                  //
                                                                       //
    board[y][x] = playerNumber + 1;                                    // 96
                                                                       //
    Games.update(game._id, {                                           // 98
      $set: {                                                          // 99
        board: board,                                                  // 100
        placingPiece: false                                            // 101
      }                                                                //
    });                                                                //
  },                                                                   //
                                                                       //
  playPiece: function (gameId, x, y) {                                 // 106
    var game = Games.findOne({ _id: gameId });                         // 107
    var board = game.board;                                            // 108
    var playerNumber = game.players.map(function (x) {                 // 109
      return x._id;                                                    //
    }).indexOf(Meteor.userId());                                       //
                                                                       //
    if (!game.placingPiece || playerNumber == -1 || playerNumber != game.currentTurn) {
      throw new Meteor.Error("not-authorized");                        // 112
    }                                                                  //
                                                                       //
    if (board[y][x] != 0) {                                            // 115
      throw new Meteor.Error("bad-request");                           // 116
    }                                                                  //
                                                                       //
    board[y][x] = playerNumber + 1;                                    // 119
                                                                       //
    if (playerHasWon(board)) {                                         // 121
      winGame(game, board);                                            // 122
    } else {                                                           //
      Games.update(game._id, {                                         // 124
        $set: {                                                        // 125
          board: board,                                                // 126
          placingPiece: false                                          // 127
        }                                                              //
      });                                                              //
    }                                                                  //
  },                                                                   //
                                                                       //
  playRotation: function (gameId, rotateX, rotateY, clockwise) {       // 133
    var game = Games.findOne({ _id: gameId });                         // 134
    var board = game.board;                                            // 135
    var playerNumber = game.players.map(function (x) {                 // 136
      return x._id;                                                    //
    }).indexOf(Meteor.userId());                                       //
                                                                       //
    // if (game.placingPiece || playerNumber == -1 || playerNumber != game.currentTurn) {
    //   throw new Meteor.Error("not-authorized");                     //
    // }                                                               //
                                                                       //
    // shitty deep copy                                                //
    var newBoard = JSON.parse(JSON.stringify(game.board));             // 143
                                                                       //
    var startX = rotateX * 3;                                          // 145
    var startY = rotateY * 3;                                          // 146
                                                                       //
    for (var x = 0; x < 3; x++) {                                      // 148
      for (var y = 0; y < 3; y++) {                                    // 149
        if (clockwise) {                                               // 150
          newBoard[x + startY][3 - y - 1 + startX] = board[startY + y][startX + x];
        } else {                                                       //
          newBoard[3 - x - 1 + startY][y + startX] = board[startY + y][startX + x];
        }                                                              //
      }                                                                //
    }                                                                  //
                                                                       //
    if (playerHasWon(newBoard)) {                                      // 158
      winGame(game, newBoard);                                         // 159
    } else {                                                           //
      Games.update(game._id, {                                         // 161
        $set: {                                                        // 162
          board: newBoard,                                             // 163
          placingPiece: true,                                          // 164
          currentTurn: (game.currentTurn + 1) % game.numberOfPlayers   // 165
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
function winGame(game, board) {                                        // 172
  Games.update(game._id, {                                             // 173
    $set: {                                                            // 174
      board: board,                                                    // 175
      state: "finished",                                               // 176
      winner: Meteor.user(),                                           // 177
      currentTurn: -1                                                  // 178
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
function playerHasWon(board) {                                         // 183
  var directions = [[0, 1], [1, 0], [1, -1], [1, 1]];                  // 184
  for (var x = 0; x < 9; x++) {                                        // 185
    for (var y = 0; y < 9; y++) {                                      // 186
      for (var i = 0; i < directions.length; i++) {                    // 187
        var direction = directions[i];                                 // 188
                                                                       //
        var length = 0;                                                // 190
        var player = board[y][x];                                      // 191
                                                                       //
        if (player != 0) {                                             // 193
          var currX = x;                                               // 194
          var currY = y;                                               // 195
                                                                       //
          while (currX < 9 && currX >= 0 && currY < 9 && currY >= 0 && board[currY][currX] == player) {
            length += 1;                                               // 198
            currX += direction[0];                                     // 199
            currY += direction[1];                                     // 200
            if (length == 5) {                                         // 201
              return true;                                             // 202
            }                                                          //
          }                                                            //
        }                                                              //
      };                                                               //
    }                                                                  //
  };                                                                   //
                                                                       //
  return false;                                                        // 210
}                                                                      //
                                                                       //
function shuffle(array) {                                              // 213
  var currentIndex = array.length,                                     // 214
      temporaryValue,                                                  //
      randomIndex;                                                     //
                                                                       //
  // While there remain elements to shuffle...                         //
  while (0 !== currentIndex) {                                         // 217
                                                                       //
    // Pick a remaining element...                                     //
    randomIndex = Math.floor(Math.random() * currentIndex);            // 220
    currentIndex -= 1;                                                 // 221
                                                                       //
    // And swap it with the current element.                           //
    temporaryValue = array[currentIndex];                              // 224
    array[currentIndex] = array[randomIndex];                          // 225
    array[randomIndex] = temporaryValue;                               // 226
  }                                                                    //
                                                                       //
  return array;                                                        // 229
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=pentago-online.jsx.map
