(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// components/Pentago.jsx                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Pentago = React.createClass({                                          // 1
  displayName: "Pentago",                                              //
                                                                       //
  getInitialState: function () {                                       // 2
    return {                                                           // 3
      currentX: null,                                                  // 4
      currentY: null,                                                  // 5
      choosingDirection: false                                         // 6
    };                                                                 //
  },                                                                   //
  componentWillMount: function () {                                    // 9
    this.squareSpacing = 60;                                           // 10
    this.colors = ["gray", "red", "blue", "green", "yellow"];          // 11
  },                                                                   //
  currentPlayerId: function () {                                       // 13
    if (this.props.game.state == "playing") {                          // 14
      return this.props.game.players[this.props.game.currentTurn]._id;
    }                                                                  //
  },                                                                   //
  isMyTurn: function () {                                              // 18
    return this.props.game.state == "playing" && Meteor.userId() == this.currentPlayerId();
  },                                                                   //
  componentDidMount: function () {                                     // 21
    var canvas = this.refs.canvas;                                     // 22
    var that = this;                                                   // 23
                                                                       //
    var squareSpacing = this.squareSpacing;                            // 25
    $(canvas).on("mousemove", function (e) {                           // 26
      var rect = canvas.getBoundingClientRect();                       // 27
      var x = e.clientX - rect.left;                                   // 28
      var y = e.clientY - rect.top;                                    // 29
      that.setState({                                                  // 30
        currentX: x / squareSpacing | 0,                               // 31
        currentY: y / squareSpacing | 0                                // 32
      });                                                              //
    });                                                                //
                                                                       //
    $(canvas).on("click", function (e) {                               // 36
      that.handleCanvasClick(e);                                       // 37
    });                                                                //
                                                                       //
    this.renderCanvas();                                               // 40
  },                                                                   //
  handleCanvasClick: function (e) {                                    // 42
    if (this.isMyTurn()) {                                             // 43
      if (this.props.game.placingPiece) {                              // 44
        if (this.props.game.board[this.state.currentY][this.state.currentX] == 0) {
          Meteor.call("playPiece", this.props.game._id, this.state.currentX, this.state.currentY);
        }                                                              //
      }                                                                //
    }                                                                  //
  },                                                                   //
  handleCounterclockwiseRotate: function () {                          // 51
    this.handleRotate(false);                                          // 52
  },                                                                   //
  handleClockwiseRotate: function () {                                 // 54
    this.handleRotate(true);                                           // 55
  },                                                                   //
  handleRotate: function (clockwise) {                                 // 57
    Meteor.call("playRotation", this.props.game._id, this.miniSquarePosition().x, this.miniSquarePosition().y, clockwise);
  },                                                                   //
  componentDidUpdate: function () {                                    // 60
    this.renderCanvas();                                               // 61
  },                                                                   //
  miniSquarePosition: function () {                                    // 63
    var miniSquareSize = this.props.miniSquareSize;                    // 64
    return {                                                           // 65
      x: this.state.currentX / miniSquareSize | 0,                     // 66
      y: this.state.currentY / miniSquareSize | 0                      // 67
    };                                                                 //
  },                                                                   //
  renderCanvas: function () {                                          // 70
    var canvas = this.refs.canvas;                                     // 71
    var ctx = canvas.getContext("2d");                                 // 72
                                                                       //
    var colors = this.colors;                                          // 74
                                                                       //
    var game = this.props.game;                                        // 76
                                                                       //
    var size = this.props.size;                                        // 78
    var miniSquareSize = this.props.miniSquareSize;                    // 79
    var squareSpacing = this.squareSpacing;                            // 80
                                                                       //
    ctx.fillStyle = "gray";                                            // 82
                                                                       //
    for (var x = 0; x < size / miniSquareSize; x++) {                  // 84
      for (var y = 0; y < size / miniSquareSize; y++) {                // 85
        ctx.beginPath();                                               // 86
        ctx.rect((x + 0.04) * squareSpacing * miniSquareSize, (y + 0.04) * squareSpacing * miniSquareSize, squareSpacing * miniSquareSize * 0.92, squareSpacing * miniSquareSize * 0.92);
                                                                       //
        if (x == this.miniSquarePosition().x && y == this.miniSquarePosition().y && this.isMyTurn() && !game.placingPiece) {
          ctx.fillStyle = "darkred";                                   // 96
          ctx.fill();                                                  // 97
          ctx.fillStyle = "gray";                                      // 98
        } else {                                                       //
          ctx.fill();                                                  // 100
        }                                                              //
                                                                       //
        ctx.stroke();                                                  // 103
      }                                                                //
    }                                                                  //
                                                                       //
    ctx.strokeStyle = "black";                                         // 107
                                                                       //
    for (var x = 0; x < size; x++) {                                   // 109
      for (var y = 0; y < size; y++) {                                 // 110
        var pixelX = squareSpacing * (x + 0.5);                        // 111
        var pixelY = squareSpacing * (y + 0.5);                        // 112
                                                                       //
        ctx.fillStyle = colors[game.board[y][x]];                      // 114
        ctx.beginPath();                                               // 115
        ctx.arc(pixelX, pixelY, this.squareSpacing * 0.35, 0, 2 * Math.PI);
        ctx.fill();                                                    // 117
        if (x == this.state.currentX && y == this.state.currentY && this.isMyTurn() && game.placingPiece) {
          ctx.strokeStyle = "red";                                     // 119
          ctx.stroke();                                                // 120
          ctx.strokeStyle = "black";                                   // 121
        } else {                                                       //
          ctx.stroke();                                                // 123
        }                                                              //
      };                                                               //
    };                                                                 //
  },                                                                   //
  render: function () {                                                // 128
    var _this = this;                                                  //
                                                                       //
    var game = this.props.game;                                        // 129
    return React.createElement(                                        // 130
      "div",                                                           //
      null,                                                            //
      React.createElement(                                             //
        "div",                                                         //
        { className: "panel panel-default" },                          //
        React.createElement(                                           //
          "div",                                                       //
          { className: "panel-body" },                                 //
          game.winner ? React.createElement(                           //
            "strong",                                                  //
            null,                                                      //
            game.winner.username,                                      //
            " has won the game!"                                       //
          ) : React.createElement(                                     //
            "strong",                                                  //
            null,                                                      //
            game.players[game.currentTurn].username,                   //
            " is about to",                                            //
            game.placingPiece ? " place a piece" : " do a rotation"    //
          )                                                            //
        )                                                              //
      ),                                                               //
      React.createElement(                                             //
        "div",                                                         //
        null,                                                          //
        this.isMyTurn() && !game.placingPiece && React.createElement(  //
          "div",                                                       //
          null,                                                        //
          React.createElement(                                         //
            "button",                                                  //
            {                                                          //
              className: "btn btn-default btn-sml",                    // 145
              style: {                                                 // 146
                left: this.miniSquarePosition().x * 60 * 3 + 10,       // 147
                marginTop: this.miniSquarePosition().y * 60 * 3,       // 148
                position: "absolute" },                                // 149
              onClick: this.handleCounterclockwiseRotate },            // 150
            React.createElement("i", { className: "fa fa-rotate-left" })
          ),                                                           //
          React.createElement(                                         //
            "button",                                                  //
            {                                                          //
              className: "btn btn-default btn-sml",                    // 154
              style: {                                                 // 155
                left: (this.miniSquarePosition().x + 1) * 60 * 3 - 20,
                marginTop: this.miniSquarePosition().y * 60 * 3,       // 157
                position: "absolute" },                                // 158
              onClick: this.handleClockwiseRotate },                   // 159
            React.createElement("i", { className: "fa fa-rotate-right" })
          )                                                            //
        ),                                                             //
        React.createElement("canvas", {                                //
          width: this.props.size * this.squareSpacing,                 // 165
          height: this.props.size * this.squareSpacing,                // 166
          ref: "canvas" })                                             // 167
      ),                                                               //
      React.createElement(                                             //
        "p",                                                           //
        null,                                                          //
        "Players:",                                                    //
        game.players.map(function (x, i) {                             //
          return React.createElement(                                  // 171
            "span",                                                    //
            { key: x.username, style: { color: _this.colors[i + 1] } },
            x.username,                                                //
            " "                                                        //
          );                                                           //
        })                                                             //
      )                                                                //
    );                                                                 //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=Pentago.jsx.map
