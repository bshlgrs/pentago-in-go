(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// components/App.jsx                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
App = React.createClass({                                              // 1
  displayName: "App",                                                  //
                                                                       //
  mixins: [ReactMeteorData],                                           // 2
                                                                       //
  getInitialState: function () {                                       // 4
    return {                                                           // 5
      state: "list"                                                    // 6
    };                                                                 //
  },                                                                   //
                                                                       //
  getMeteorData: function () {                                         // 10
    return {                                                           // 11
      games: Games.find({}).fetch(),                                   // 12
      gamesGettingPlayers: Games.find({ state: "getting-players" }).fetch(),
      gamesPlaying: Games.find({ state: "playing" }).fetch(),          // 14
      gamesFinished: Games.find({ state: "finished" }).fetch()         // 15
    };                                                                 //
  },                                                                   //
                                                                       //
  handleGameSelect: function (_id) {                                   // 19
    this.setState({ state: "view-game", currentGameId: _id });         // 20
  },                                                                   //
                                                                       //
  goToMainMenu: function () {                                          // 23
    this.setState({ state: "list" });                                  // 24
  },                                                                   //
                                                                       //
  handleCreateGame: function (event) {                                 // 27
    event.preventDefault();                                            // 28
                                                                       //
    // Find the text field via the React ref                           //
    var name = ReactDOM.findDOMNode(this.refs.nameInput).value.trim();
    var numberOfPlayers = parseInt(document.querySelector('input[name="playerNumber"]:checked').value);
    var that = this;                                                   // 33
                                                                       //
    Meteor.call("createGame", name, numberOfPlayers, function (err, gameId) {
      that.setState({ state: "view-game", currentGameId: gameId });    // 36
    });                                                                //
  },                                                                   //
                                                                       //
  render: function () {                                                // 40
    var _this = this;                                                  //
                                                                       //
    // Get tasks from this.data.tasks                                  //
                                                                       //
    var inner = React.createElement("p", null);                        // 43
                                                                       //
    if (this.state.state == "list") {                                  // 45
      inner = React.createElement(                                     // 46
        "div",                                                         //
        null,                                                          //
        React.createElement(                                           //
          "div",                                                       //
          { className: "panel panel-default" },                        //
          React.createElement(                                         //
            "div",                                                     //
            { className: "panel-body" },                               //
            React.createElement(                                       //
              "h3",                                                    //
              null,                                                    //
              "Join a game!"                                           //
            ),                                                         //
            this.data.games.length ? React.createElement(              //
              "ul",                                                    //
              null,                                                    //
              this.data.gamesGettingPlayers.map(function (game) {      //
                return React.createElement(GameListItem, { handleGameSelect: _this.handleGameSelect, key: game._id, game: game });
              })                                                       //
            ) : React.createElement(                                   //
              "p",                                                     //
              null,                                                    //
              "No games currently exist, create one?"                  //
            )                                                          //
          )                                                            //
        ),                                                             //
        React.createElement(                                           //
          "div",                                                       //
          { className: "panel panel-default" },                        //
          React.createElement(                                         //
            "div",                                                     //
            { className: "panel-body" },                               //
            React.createElement(                                       //
              "h3",                                                    //
              null,                                                    //
              "Currently live matches"                                 //
            ),                                                         //
            this.data.games.length ? React.createElement(              //
              "ul",                                                    //
              null,                                                    //
              this.data.gamesPlaying.map(function (game) {             //
                return React.createElement(GameListItem, { handleGameSelect: _this.handleGameSelect, key: game._id, game: game });
              })                                                       //
            ) : React.createElement(                                   //
              "p",                                                     //
              null,                                                    //
              "No-one is playing right now :("                         //
            )                                                          //
          )                                                            //
        ),                                                             //
        React.createElement(                                           //
          "div",                                                       //
          { className: "panel panel-default" },                        //
          React.createElement(                                         //
            "div",                                                     //
            { className: "panel-body" },                               //
            React.createElement(                                       //
              "h3",                                                    //
              null,                                                    //
              "Make new game!"                                         //
            ),                                                         //
            React.createElement(                                       //
              "form",                                                  //
              { onSubmit: this.handleCreateGame },                     //
              React.createElement("input", {                           //
                className: "form-control",                             // 81
                type: "text",                                          // 82
                ref: "nameInput",                                      // 83
                placeholder: "Name of game" }),                        // 84
              React.createElement(                                     //
                "div",                                                 //
                { className: "radio" },                                //
                [2, 3, 4].map(function (n) {                           //
                  return React.createElement(                          // 87
                    "label",                                           //
                    { key: n, className: "radio-inline" },             //
                    React.createElement("input", { type: "radio", name: "playerNumber", value: n }),
                    " ",                                               //
                    n,                                                 //
                    " players"                                         //
                  );                                                   //
                })                                                     //
              ),                                                       //
              React.createElement(                                     //
                "button",                                              //
                { className: "btn btn-primary", type: "submit" },      //
                "Create game"                                          //
              )                                                        //
            )                                                          //
          )                                                            //
        ),                                                             //
        React.createElement(                                           //
          "div",                                                       //
          { className: "panel panel-default" },                        //
          React.createElement(                                         //
            "div",                                                     //
            { className: "panel-body" },                               //
            React.createElement(                                       //
              "h3",                                                    //
              null,                                                    //
              "Old matches"                                            //
            ),                                                         //
            this.data.games.length ? React.createElement(              //
              "ul",                                                    //
              null,                                                    //
              this.data.gamesFinished.map(function (game) {            //
                return React.createElement(GameListItem, { handleGameSelect: _this.handleGameSelect, key: game._id, game: game });
              })                                                       //
            ) : React.createElement(                                   //
              "p",                                                     //
              null,                                                    //
              "No-one has played yet :("                               //
            )                                                          //
          )                                                            //
        )                                                              //
      );                                                               //
    } else if (this.state.state == "view-game") {                      //
      inner = React.createElement(ShowGame, { game: Games.findOne({ _id: this.state.currentGameId }) });
    }                                                                  //
                                                                       //
    return React.createElement(                                        // 118
      "div",                                                           //
      null,                                                            //
      React.createElement(                                             //
        "div",                                                         //
        { className: "pull-right" },                                   //
        React.createElement(AccountsUIWrapper, null)                   //
      ),                                                               //
      React.createElement(                                             //
        "h1",                                                          //
        { onClick: this.goToMainMenu },                                //
        React.createElement(                                           //
          "a",                                                         //
          null,                                                        //
          "pentago online"                                             //
        )                                                              //
      ),                                                               //
      inner                                                            //
    );                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
GameListItem = React.createClass({                                     // 128
  displayName: "GameListItem",                                         //
                                                                       //
  handleClick: function () {                                           // 129
    this.props.handleGameSelect(this.props.game._id);                  // 130
  },                                                                   //
  render: function () {                                                // 132
    var game = this.props.game;                                        // 133
                                                                       //
    var inner;                                                         // 135
                                                                       //
    if (this.props.game.state == "getting-players") {                  // 137
      inner = React.createElement(                                     // 138
        "span",                                                        //
        null,                                                          //
        game.players.length ? React.createElement(                     //
          "span",                                                      //
          null,                                                        //
          "Players: ",                                                 //
          game.players.map(function (x) {                              //
            return x.username;                                         //
          }).join(","),                                                //
          "."                                                          //
        ) : React.createElement(                                       //
          "span",                                                      //
          null,                                                        //
          game.numberOfPlayers,                                        //
          " player game. "                                             //
        ),                                                             //
        " Needs ",                                                     //
        game.numberOfPlayers - game.players.length,                    //
        " more players."                                               //
      );                                                               //
    } else if (game.state == "playing") {                              //
      inner = React.createElement(                                     // 147
        "span",                                                        //
        null,                                                          //
        "Players: ",                                                   //
        game.players.map(function (x) {                                //
          return x.username;                                           //
        }).join(","),                                                  //
        ". Current turn: ",                                            //
        game.players[game.currentTurn].username,                       //
        "."                                                            //
      );                                                               //
    } else if (game.state == "finished") {                             //
      inner = React.createElement(                                     // 152
        "span",                                                        //
        null,                                                          //
        game.winner.username,                                          //
        " won!"                                                        //
      );                                                               //
    }                                                                  //
                                                                       //
    return React.createElement(                                        // 155
      "li",                                                            //
      null,                                                            //
      React.createElement(                                             //
        "a",                                                           //
        { onClick: this.handleClick },                                 //
        game.name                                                      //
      ),                                                               //
      " ",                                                             //
      inner                                                            //
    );                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
ShowGame = React.createClass({                                         // 161
  displayName: "ShowGame",                                             //
                                                                       //
  handleJoin: function () {                                            // 162
    Meteor.call("joinGame", this.props.game._id);                      // 163
  },                                                                   //
  render: function () {                                                // 165
    var game = this.props.game;                                        // 166
                                                                       //
    var inner = React.createElement("p", null);                        // 168
                                                                       //
    if (game.state == "getting-players") {                             // 170
      inner = React.createElement(                                     // 171
        "div",                                                         //
        null,                                                          //
        React.createElement(                                           //
          "p",                                                         //
          null,                                                        //
          "Currently getting players!"                                 //
        ),                                                             //
        game.players.length ? React.createElement(                     //
          "div",                                                       //
          null,                                                        //
          React.createElement(                                         //
            "p",                                                       //
            null,                                                      //
            "Players:"                                                 //
          ),                                                           //
          React.createElement(                                         //
            "ul",                                                      //
            null,                                                      //
            game.players.map(function (x) {                            //
              return React.createElement(                              // 178
                "li",                                                  //
                { key: x._id },                                        //
                x.username                                             //
              );                                                       //
            })                                                         //
          )                                                            //
        ) : null,                                                      //
        game.players.map(function (x) {                                //
          return x._id;                                                //
        }).indexOf(Meteor.userId()) == -1 ? React.createElement(       //
          "button",                                                    //
          { className: "btn btn-primary", onClick: this.handleJoin },  //
          "Join game!"                                                 //
        ) : null                                                       //
      );                                                               //
    } else if (game.state == "playing") {                              //
      inner = React.createElement(                                     // 189
        "div",                                                         //
        null,                                                          //
        React.createElement(Pentago, { size: 9, miniSquareSize: 3, game: game })
      );                                                               //
    } else if (game.state == "finished") {                             //
      inner = React.createElement(                                     // 193
        "div",                                                         //
        null,                                                          //
        React.createElement(Pentago, { size: 9, miniSquareSize: 3, game: game })
      );                                                               //
    }                                                                  //
                                                                       //
    return React.createElement(                                        // 198
      "div",                                                           //
      null,                                                            //
      React.createElement(                                             //
        "h3",                                                          //
        null,                                                          //
        this.props.game.name                                           //
      ),                                                               //
      inner                                                            //
    );                                                                 //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=App.jsx.map
